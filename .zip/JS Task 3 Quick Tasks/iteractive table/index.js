"use strictct"

let table = document.querySelector(`table`);
table.ondragstart = function() {
  return false
}

table.addEventListener(`pointerdown`, catchItem) 

let trigger = 0;

function catchItem() {

  if (trigger) {
    return;
  }
  
  let target = event.target.closest(`td`);

  let shiftX = event.clientX - target.getBoundingClientRect().left
  let shiftY = event.clientY - target.getBoundingClientRect().top

  let movingTarget = document.createElement(`td`);
  movingTarget.innerHTML = target.innerHTML;
  movingTarget.classList.add(`movingtarget`)
  movingTarget.style.top = event.pageY - shiftY + `px`
  movingTarget.style.left = event.pageX - shiftX + `px`
  document.body.append(movingTarget)

  movingTarget.addEventListener(`pointermove`, moveAt)

  let elemBelow;

  function moveAt() {

    movingTarget.style.top = event.pageY - shiftY + `px`
    movingTarget.style.left = event.pageX - shiftX + `px`

    movingTarget.hidden = true;
    elemBelow = document.elementFromPoint(event.clientX, event.clientY).closest(`td`)
    movingTarget.hidden = false;

  }

  movingTarget.addEventListener(`pointerup`, releaseItem) 

    
    function releaseItem() {

      movingTarget.hidden = true;
      elemBelow = document.elementFromPoint(event.clientX, event.clientY).closest(`td`)
      movingTarget.hidden = false;

      movingTarget.removeEventListener(`pointermove`, moveAt)
      
      if(!elemBelow) {
        movingTarget.remove()
      }

      if(elemBelow == target) {
        movingTarget.remove()
        editCell()
      } else {
        if(elemBelow) {
        target.innerHTML = elemBelow.innerHTML;
        elemBelow.innerHTML = movingTarget.innerHTML;
        movingTarget.remove()
        } 
      }

      function editCell() {

        trigger = 1;

        let textArea = document.createElement(`textarea`);
        textArea.value = elemBelow.innerHTML;
        textArea.style.height = elemBelow.clientHeight + `px`
        textArea.style.width = elemBelow.clientWidth + `px`
        elemBelow.innerHTML = ``;

        elemBelow.append(textArea)
        textArea.focus()
      
        document.addEventListener(`keydown`, editFinished)
      
        function editFinished() {
          console.log(event)
          if (event.code == `Enter` || event.code == `Escape`) {
            elemBelow.innerHTML = textArea.value;
            trigger = 0;
            textArea.remove()
          }
        }
      }
    }
    
  }
  







