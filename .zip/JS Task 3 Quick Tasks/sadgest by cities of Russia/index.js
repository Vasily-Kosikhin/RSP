"use strictct"

const townUrl = `https://gist.githubusercontent.com/gorborukov/0722a93c35dfba96337b/raw/435b297ac6d90d13a68935e1ec7a69a225969e58/russia`

async function f() {
  let responde = await fetch(townUrl);
  let russianTowns = await responde.json();

  russianTowns.sort((a, b) => {
    if (a.city.trim() > b.city.trim()) {
      return 1
    } else {
      return -1
    }
  })

  let entryField = document.querySelector(`#entryField`)
  let townsTips = document.querySelector(`#townsTips`)
  let entryFieldCoords = entryField.getBoundingClientRect()

  townsTips.style.top = entryFieldCoords.bottom + 10 + `px`
  entryField.addEventListener(`input`, createTips)

  function createTips() {

  clearTips();
    
    let usersInput = entryField.value;
    let tipsArray = [];

    for (let part of russianTowns) {
      if (part.city.toUpperCase().startsWith(usersInput.toUpperCase())) {
        tipsArray.push(part.city)
      }
    }

    for (let i = 0; i < 4; i++) {
      if (usersInput == ``) {
        break;
      } else {
        if (tipsArray[i]) {
          let newTip = document.createElement(`li`);
          newTip.innerHTML = tipsArray[i];
          townsTips.append(newTip)
        }
      }
    }

    function clearTips() {
      for (let tips of townsTips.querySelectorAll(`li`)) {
        tips.remove()
      }
    }

    if (!townsTips.querySelector(`li`) && usersInput != ``) {
      let newTip = document.createElement(`li`);
        newTip.innerHTML = `Такого города нет, посетите Калугу!`;
        newTip.style.textAlign = `center`;
        townsTips.append(newTip)
    }
  }
}

f()


