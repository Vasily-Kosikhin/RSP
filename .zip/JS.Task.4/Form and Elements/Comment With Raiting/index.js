  "use strictct"


const form = document.querySelector(`form`)
const comment = document.querySelector(`#comment`)
const starsBar = document.querySelector(`#stars`)
class Feedback {
  constructor(raiting, comment) {
    this.raiting = raiting;
    this.comment = comment;
  }
}

stars.addEventListener(`click`, colorizeStars)

function colorizeStars() {
  let stars = starsBar.querySelectorAll(`i`);
  let target = event.target

  let trigger = true;
  for (let i = 0; i < stars.length; i++) {
    if(stars[i] == target) {
      stars[i].classList.replace(`notSelected`, `selected`)
      console.log(`MAIN STEP`, i)
      trigger = false;
    } else if (trigger) {
      stars[i].classList.replace(`notSelected`, `selected`)
      console.log(`ADD STEP`, i)
    } else {
      stars[i].classList.replace(`selected`, `notSelected`)
      console.log(`REMOVE STEP`, i, `classList`, stars[i].classList)
    }
  }
  comment.focus()
}


form.addEventListener(`submit`, submitFrom);



function submitFrom() {
  let raiting = document.querySelectorAll(`.selected`).length

  if(comment.value.length > 10 && raiting > 0) {
    let feedback = new Feedback(raiting, comment.value)
    console.log(feedback)
    alert(`Вы справились смотрите в консоль`)
  } else if(comment.value.length < 10) {
    alert(`Оставьте отзыв побольше`)
  } else if(raiting < 1) {
    alert(`Поставьте оценку`)
  }
  event.preventDefault()
}
