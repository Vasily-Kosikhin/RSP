  "use strictct"


let form = document.querySelector(`form`)
const notice = document.querySelector(`#notAllowed`)
notice.hidden = true;

console.log(form.elements[0].checked)

form.addEventListener(`submit`, submitFrom);

function submitFrom() {
  console.log(form)
  console.log(notice.style.top)
  if(form.elements[0].checked) {
    form.classList.remove(`error`)
    notice.innerHTML = `Mans not allowed`
    notice.hidden = false;
    notice.style.top = form.elements[0].getBoundingClientRect().top + notice.clientHeight + `px`
    notice.style.left = form.getBoundingClientRect().left + form.clientWidth / 2 - notice.clientWidth / 2 + `px`
    event.preventDefault()
  }
  if(form.elements[1].checked) {
    form.classList.remove(`error`)
    notice.innerHTML = `Womans not allowed`
    notice.hidden = false;
    notice.style.top = form.elements[0].getBoundingClientRect().top + notice.clientHeight + `px`
    notice.style.left = form.getBoundingClientRect().left + form.clientWidth / 2 - notice.clientWidth / 2 + `px`
    event.preventDefault()
  }
  if(!form.elements[1].checked && !form.elements[0].checked) {
    notice.innerHTML = `Check your gender for entrance`
    form.classList.add(`error`)
    notice.hidden = false;
    notice.style.top = form.elements[0].getBoundingClientRect().top + notice.clientHeight + `px`
    notice.style.left = form.getBoundingClientRect().left + form.clientWidth / 2 - notice.clientWidth / 2 + `px`
    event.preventDefault()
  }
}