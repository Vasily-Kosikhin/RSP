  "use strictct"

const townUrl = `https://gist.githubusercontent.com/gorborukov/0722a93c35dfba96337b/raw/435b297ac6d90d13a68935e1ec7a69a225969e58/russia`

let form = document.querySelector(`form`)

console.log(form.elements[0].checked)

form.addEventListener(`submit`, agreementChecker)

function agreementChecker() {
  if(form.elements[0].checked == false) {

    form.elements[0].classList.add(`error`);

    let notice = document.createElement(`div`)
    notice.innerHTML = `Подтвердите отправку`
    document.body.append(notice)
    notice.style.position = `absolute`
    notice.style.top = form.elements[0].getBoundingClientRect().top + notice.clientHeight + `px`
    notice.style.left = form.elements[0].getBoundingClientRect().left + `px`
    notice.style.color = `red`
    
    console.log(notice.clientHeight)

    event.preventDefault()
  } 
} 