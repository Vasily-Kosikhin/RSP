  "use strictct"

  const form = document.querySelector(`#logForm`);
  const loginInput = document.forms[0].elements[0]
  const passwordInput = document.forms[0].elements[1]

  document.addEventListener(`submit`, checkLoginAndPassword);
  console.log(document.forms[0].elements[0])
  function checkLoginAndPassword() {
    if (loginInput.value == ``) {
      loginInput.classList.add(`error`)
      event.preventDefault()
    }
    if (passwordInput.value == ``) {
      passwordInput.classList.add(`error`)
      event.preventDefault()
    }
  }
  

